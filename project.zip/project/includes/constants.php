<?php

    /**
     * constants.php
     *
     * Computer Science 50
     * Project
     *
     * Global constants.
     */

    // your database's name
    define("DATABASE", "projectnamehere");

    // your database's password
    define("PASSWORD", "passwordhere");

    // your database's server
    define("SERVER", "localhost");

    // your database's username
    define("USERNAME", "usernamehere");

?>
