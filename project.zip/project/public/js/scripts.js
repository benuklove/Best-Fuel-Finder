/**
 * scripts.js
 *
 * Computer Science 50
 * Project
 *
 * Global JavaScript.
 *
 * Functions will be factored out of html and put here
 */
